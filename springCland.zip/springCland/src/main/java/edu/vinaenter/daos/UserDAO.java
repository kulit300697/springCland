package edu.vinaenter.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import edu.vinaenter.constants.SQL.UserSQLConstant;
import edu.vinaenter.models.User;

@Repository
public class UserDAO extends AbstractDao<User> {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<User> selectAll() {
		return jdbcTemplate.query(UserSQLConstant.SELECT_ALL, new BeanPropertyRowMapper<User>(User.class));
	}
	
	public List<User> selectLogin() {
		return jdbcTemplate.query(UserSQLConstant.SELECT_LOGIN, new BeanPropertyRowMapper<User>(User.class));
	}

	@Override
	public User selectByID(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int add(User t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int del(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int edit(User t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<User> search(String search) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int countAll() {
		return jdbcTemplate.queryForObject(UserSQLConstant.COUNT_ALL, Integer.class);
	}
	
}
