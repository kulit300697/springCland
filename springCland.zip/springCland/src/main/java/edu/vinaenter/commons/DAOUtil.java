package edu.vinaenter.commons;

public class DAOUtil {
	public static boolean isSuccess(int result) {
		return result >0 ;
	}
}
