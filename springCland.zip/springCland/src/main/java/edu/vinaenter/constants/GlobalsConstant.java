package edu.vinaenter.constants;

public class GlobalsConstant {
	public static final String URL = "jdbc:mysql://localhost:3306/Cland?useUnicode=true&characterEncoding=UTF-8";
	public static final String USERNAME ="root";
	public static final String PASSWORD ="12345678";
	public static final String DRIVER ="com.mysql.jdbc.Driver";
}
