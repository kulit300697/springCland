package edu.vinaenter.constants.SQL;

public class UserSQLConstant {
	public static final String SELECT_ALL = "SELECT * FROM users ORDER BY uid DESC ";
	
	public static final String SELECT_LOGIN = "SELECT * FROM users ";
	
	public static final String COUNT_ALL = "SELECT COUNT(*) FROM users";
}
