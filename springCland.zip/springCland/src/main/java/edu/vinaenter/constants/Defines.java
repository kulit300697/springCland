package edu.vinaenter.constants;

public class Defines {
	public static final int ROW_COUNT = 4;
	
	public static final int SELECT_SLIDER = 3;
	
	public static final int SELECT_LIMIT = 5;
	
}
