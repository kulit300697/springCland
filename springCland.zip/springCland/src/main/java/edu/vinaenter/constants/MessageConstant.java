package edu.vinaenter.constants;

public class MessageConstant {
	public static final String MSG_SUCCESS_ADD = "Thêm thành công";
	public static final String MSG_ERR = "Fail";
	public static final String MSG_SUCCESS_DEL = "Xóa thành công";
	public static final String MSG_SUCCESS_EDIT = "Sửa thành công";
	public static final String DIR_UPLOAD = "uploads";
	public static final String MSG_CONTACT_ADD = "Gửi thành công";
	public static final String LOGIN_SUCCESS = "Đăng nhập thành công";
	public static final String LOGIN_ERR = "Đăng nhập thất bại";
	public static final String LOGIN = "Vui lòng đăng nhập";
}
