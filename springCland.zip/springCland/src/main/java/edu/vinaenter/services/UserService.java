package edu.vinaenter.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.vinaenter.daos.UserDAO;
import edu.vinaenter.models.User;

@Service
public class UserService {
	@Autowired
	private UserDAO userDAO;
	public List<User> selectAll(){
		return userDAO.selectAll();
	}
	public int countAll() {
		return userDAO.countAll();
	}
	public List<User> selectLogin() {
		return userDAO.selectLogin();
	}
}
