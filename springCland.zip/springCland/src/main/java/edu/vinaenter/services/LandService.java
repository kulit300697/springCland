package edu.vinaenter.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.vinaenter.daos.LandDAO;
import edu.vinaenter.models.Land;

@Service
public class LandService {
	@Autowired
	private LandDAO landDAO;
	public List<Land> selectAll() {
		return landDAO.selectAll();
	}
	public List<Land> selectSlider(){
		return landDAO.selectSlider();
	}
	public int countAll() {
		return landDAO.countAll();
	}
	public List<Land> selectAllDateNew() {
		return landDAO.selectAllDateNew();
	}
	public List<Land> selectAllCountView() {
		return landDAO.selectAllCountView();
	}
	public List<Land> selectByCid(int cid){
		return landDAO.selectByCid(cid);
	}
}
