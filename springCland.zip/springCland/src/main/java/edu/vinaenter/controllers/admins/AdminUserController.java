package edu.vinaenter.controllers.admins;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.vinaenter.models.User;
import edu.vinaenter.services.UserService;

@Controller 
@RequestMapping("admin/user")
public class AdminUserController {
	@Autowired
	private UserService userService;
	@GetMapping("index")
	public String index(Model model) {
		List<User> listUser = userService.selectAll();
		model.addAttribute("listUser", listUser);
		return "admin.user.index";
	}
}
