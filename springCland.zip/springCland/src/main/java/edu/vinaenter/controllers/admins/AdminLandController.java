package edu.vinaenter.controllers.admins;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.vinaenter.models.Category;
import edu.vinaenter.models.Land;
import edu.vinaenter.services.CategoryService;
import edu.vinaenter.services.LandService;

@Controller
@RequestMapping("admin/land")
public class AdminLandController {
	@Autowired
	private LandService landService;
	@Autowired
	private CategoryService categoryService;
	
	@GetMapping("index")
	public String index(Model model) {
		List<Category> listCat = categoryService.selectAll();
		model.addAttribute("listCat", listCat);
		List<Land> listLand = landService.selectAll();
		model.addAttribute("listLand", listLand);
		return "admin.land.index";
	}
}
