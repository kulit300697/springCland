package edu.vinaenter.controllers.admins;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.vinaenter.models.Contact;
import edu.vinaenter.services.ContactService;

@Controller 
@RequestMapping("admin/contact")
public class AdminContactController {
	@Autowired
	private ContactService contactService;
	@GetMapping("index")
	public String index(Model model) {
		List<Contact> listContact = contactService.selectAll();
		model.addAttribute("listContact", listContact);
		return "admin.contact.index";
	}
}
